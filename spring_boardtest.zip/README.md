#  💻CSS / HTML / JavaScript 를 활용한 웹퍼블리싱💻
프로젝트기간 2023년 10월 16 ~ 2023년 10월27일


## 🔨개인프로젝트🔨

```python
# Oc_ProJect
CSS / HTML /JavaSCript Web_Project
```

## 👋 설명👋

![ocweb](https://github.com/wwnoov/ww_project/assets/145524959/e982d9c0-8d04-4739-8588-775120880d51)



## :page_with_curl:사용기술:page_with_curl:

<img src="https://img.shields.io/badge/HTML5-E34F26?style=flat&logo=HTML5&logoColor=white" />
<img src="https://img.shields.io/badge/CSS3-1572B6?style=flat&logo=CSS3&logoColor=white" />
<img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=flat&logo=JavaScript&logoColor=white" />

